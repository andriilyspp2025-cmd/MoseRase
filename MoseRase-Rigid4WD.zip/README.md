# MoseRase 4×4

[Збірка цільної рами](rigid-4wd/README.md)
