Відкрийте [інструкцію FanKit](fan-kit/README.md) і FanKit.scad.
Для рами з вентиляторами використовуйте STL із fan-kit/stl. Деталі ходової лежать у stl, основна інструкція у docs.
