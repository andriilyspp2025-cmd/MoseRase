# MoseRase 4×4 без ременів

[Інструкція з друку й складання](axle-drive/README.md)
